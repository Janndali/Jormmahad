superpixels-SLIC
================

Superpixel segmentation using SLIC with Python.
